package com.example.minimalapp

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this).apply {
            text = "Hello from Kotlin!"
            textSize = 24f
            setPadding(50, 200, 50, 50)
        }
        setContentView(tv)
    }
}
